import pandas as pd
from typing import Optional, Tuple
import holidays


class DataHandling:
    def __init__(self, min_points: int = 30, allow_negative: bool = False, lookback_days: int = 90):
        self.min_points = min_points
        self.allow_negative = allow_negative
        self.lookback_days = lookback_days

        # Holiday calendars
        self.us_holidays = holidays.US()
        self.india_holidays = holidays.India()

    def sanitize(
        self,
        df: pd.DataFrame,
        date_col: str,
        metric_col: str
    ) -> Tuple[Optional[pd.Series], list]:
        """
        Structural sanitization ONLY.
        No reindexing, no filling, no test contamination.
        """

        logs = []

        # Column checks
        if date_col not in df.columns:
            logs.append(f"ERROR: Date column '{date_col}' missing")
            return None, logs

        if metric_col not in df.columns:
            logs.append(f"ERROR: Metric '{metric_col}' missing")
            return None, logs

        # Parse & clean
        out = df[[date_col, metric_col]].copy()
        out[date_col] = pd.to_datetime(out[date_col], errors="coerce")
        out[metric_col] = pd.to_numeric(out[metric_col], errors="coerce")
        out = out.dropna(subset=[date_col])

        # Deduplicate & sort
        out = out.drop_duplicates(subset=[date_col], keep="last")
        out = out.sort_values(date_col)
        out = out.set_index(date_col)

        series = out[metric_col]

        # Negative handling
        if not self.allow_negative:
            neg_count = int((series < 0).sum())
            if neg_count > 0:
                series = series.clip(lower=0)
                logs.append(f"WARN: {neg_count} negative values clipped to 0")

        # Minimum data check (non-null only)
        if series.notna().sum() < self.min_points:
            logs.append(
                f"SKIP: Only {series.notna().sum()} non-null points "
                f"(min required = {self.min_points})"
            )
            return None, logs

        # Outlier clipping (IQR)
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1

        if iqr > 0:
            lower = q1 - 3.0 * iqr
            upper = q3 + 3.0 * iqr
            outliers = ((series < lower) | (series > upper)).sum()
            if outliers > 0:
                series = series.clip(lower=lower, upper=upper)
                logs.append(
                    f"WARN: {outliers} outliers clipped using IQR bounds "
                    f"[{lower:.2f}, {upper:.2f}]"
                )

        # IMPORTANT:
        # ❌ No reindex
        # ❌ No fill
        # ❌ No dropna here

        return series, logs

    def impute_train(self, series: pd.Series) -> pd.Series:
        """
        Train-only imputation.
        Reindex to daily frequency and fill missing values.
        """

        if series is None or series.empty:
            return series

        # Daily reindex
        full_idx = pd.date_range(
            start=series.index.min(),
            end=series.index.max(),
            freq="D"
        )
        series = series.reindex(full_idx)

        def is_weekend_or_holiday(ts):
            d = ts.date()
            return (
                ts.weekday() >= 5
                or d in self.us_holidays
                or d in self.india_holidays
            )

        for ts in series[series.isna()].index:
            # Weekend / holiday → 0
            if is_weekend_or_holiday(ts):
                series.loc[ts] = 0
            else:
                # Weekday → last-quarter weekday median
                start = ts - pd.Timedelta(days=self.lookback_days)
                history = series.loc[start:ts - pd.Timedelta(days=1)]
                history = history.dropna()

                if not history.empty:
                    series.loc[ts] = history.median()

        # Final safety check
        series = series.dropna()

        if len(series) < self.min_points:
            return series

        return series
