# services/tft_engine.py

import pandas as pd
import numpy as np

from utils.metrics import wmape

from pytorch_forecasting import TimeSeriesDataSet, TemporalFusionTransformer
from pytorch_forecasting.metrics import QuantileLoss
from pytorch_lightning import Trainer
import torch


class TFTEngine:
    def __init__(self, max_epochs: int = 10):
        self.max_epochs = max_epochs

    def run_tft(self, series: pd.Series, feature_df=None):
        # ---- SAFETY GATE ----
        if len(series) < 200:
            raise RuntimeError("TFT skipped: insufficient data")

        # ---- PREPARE DATA ----
        df = pd.DataFrame({
            "time_idx": np.arange(len(series)),
            "y": series.values,
            "series_id": 0,
        }, index=series.index)

        split_idx = int(len(df) * 0.8)
        train_df = df.iloc[:split_idx]
        test_df = df.iloc[split_idx:]

        max_encoder_length = 30
        max_prediction_length = min(60, len(test_df))

        training_ds = TimeSeriesDataSet(
            train_df,
            time_idx="time_idx",
            target="y",
            group_ids=["series_id"],
            max_encoder_length=max_encoder_length,
            max_prediction_length=max_prediction_length,
            time_varying_unknown_reals=["y"],
        )

        val_ds = TimeSeriesDataSet.from_dataset(
            training_ds,
            test_df,
            predict=True,
            stop_randomization=True,
        )

        train_loader = training_ds.to_dataloader(train=True, batch_size=32, num_workers=0)
        val_loader = val_ds.to_dataloader(train=False, batch_size=32, num_workers=0)

        # ---- MODEL ----
        tft = TemporalFusionTransformer.from_dataset(
            training_ds,
            learning_rate=0.03,
            hidden_size=16,
            attention_head_size=4,
            dropout=0.1,
            hidden_continuous_size=8,
            loss=QuantileLoss(),
            output_size=7,
        )

        # ---- TRAINER (CPU SAFE) ----
        trainer = Trainer(
            max_epochs=self.max_epochs,
            accelerator="cpu",
            devices=1,
            enable_checkpointing=False,
            logger=False,
            enable_model_summary=False,
        )

        # ---- TRAIN ----
        trainer.fit(tft, train_loader, val_loader)

        # ---- TEST PREDICTIONS (CORRECT WAY) ----
        preds = trainer.predict(tft, val_loader)

        y_pred = torch.cat(preds).detach().cpu().numpy()[:, 0]
        y_true = test_df["y"].values

        test_pred = pd.Series(y_pred, index=test_df.index)
        score = wmape(y_true, y_pred)

        # ---- FUTURE FORECAST ----
        horizon = 60
        future_idx = pd.date_range(
            start=series.index.max() + pd.Timedelta(days=1),
            periods=horizon,
            freq="D",
        )

        future_df = pd.DataFrame({
            "time_idx": np.arange(df["time_idx"].iloc[-1] + 1,
                                  df["time_idx"].iloc[-1] + 1 + horizon),
            "y": np.nan,
            "series_id": 0,
        })

        future_ds = TimeSeriesDataSet.from_dataset(
            training_ds,
            future_df,
            predict=True,
            stop_randomization=True,
        )

        future_loader = future_ds.to_dataloader(train=False, batch_size=32, num_workers=0)
        future_preds = trainer.predict(tft, future_loader)

        forecast_vals = torch.cat(future_preds).detach().cpu().numpy()[:, 0]
        forecast = pd.Series(forecast_vals, index=future_idx)

        return {
            "train": train_df["y"],
            "test": test_df["y"],
            "test_pred": test_pred,
            "forecast": forecast,
            "best_model": "TFT",
            "wmape": score,
            "accuracy": round((1 - score) * 100, 2),
        }
