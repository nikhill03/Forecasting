import pandas as pd
import numpy as np
import holidays

import lightgbm as lgb

from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    HistGradientBoostingRegressor,
)

from utils.metrics import wmape
from xgboost import XGBRegressor
import logging 
logger = logging.getLogger("services.mulitivariate_engine")

class MultivariateEngine:
    def __init__(self):
        self.us_holidays= holidays.US()
        self.india_holidays = holidays.India()
        self.holidays = set(self.us_holidays) | set(self.india_holidays)

    # Feature Engineering (Calendar + Peak Day + Holiday)
    def _add_features(self, df):
        df = df.copy()
        df["day_of_week"] = df.index.dayofweek
        df["week_of_month"] = (df.index.day - 1) // 7 + 1
        df["month_of_year"] = df.index.month
        df["quarter_of_year"] = df.index.quarter
        df["year"] = df.index.year
        df["t"] = np.arange(len(df))

        # Peak day based on 70th percentile
        p70 = df["y"].quantile(0.70)
        df["peak_day"] = (df["y"] > p70).astype(int)

        # Holiday flag
        df["is_holiday"] = df.index.to_series().apply(lambda d: int(d in self.holidays))
        holiday_set = set(self.holidays)
        df["before_holiday_1"] = df.index.to_series().apply(lambda d: int((d + pd.Timedelta(days=1)) in holiday_set))
        df["before_holiday_2"] = df.index.to_series().apply(lambda d: int((d + pd.Timedelta(days=2)) in holiday_set))
        df["after_holiday_1"] = df.index.to_series().apply(lambda d: int((d - pd.Timedelta(days=1)) in holiday_set))
        df["after_holiday_2"] = df.index.to_series().apply(lambda d: int((d - pd.Timedelta(days=2)) in holiday_set))

        return df

    # Future feature dataframe (60 days)
    def _make_future_df(self, last_date, periods, last_t, recent_y):
        idx = pd.date_range(start=last_date + pd.Timedelta(days=1),periods=periods,freq="D")
        fdf = pd.DataFrame(index=idx)

        fdf["day_of_week"] = fdf.index.dayofweek
        fdf["week_of_month"] = (fdf.index.day - 1) // 7 + 1
        fdf["month_of_year"] = fdf.index.month
        fdf["quarter_of_year"] = fdf.index.quarter
        fdf["year"] = fdf.index.year
        fdf["peak_day"] = int(recent_y.tail(30).quantile(0.7))


        holiday_set = set(self.holidays)
        fdf["is_holiday"] = fdf.index.to_series().apply(lambda d: int(d in self.holidays))

        fdf["before_holiday_1"] = fdf.index.to_series().apply(lambda d: int((d + pd.Timedelta(days=1)) in holiday_set))
        fdf["before_holiday_2"] = fdf.index.to_series().apply(lambda d: int((d + pd.Timedelta(days=2)) in holiday_set))
        fdf["after_holiday_1"] = fdf.index.to_series().apply(lambda d: int((d - pd.Timedelta(days=1)) in holiday_set))
        fdf["after_holiday_2"] = fdf.index.to_series().apply(lambda d: int((d - pd.Timedelta(days=2)) in holiday_set))
        fdf["t"] = np.arange(last_t + 1, last_t + 1 + periods)

        return fdf

    # Feature Selection (Top 70%)
    def _select_features(self, X, y):

        rf = RandomForestRegressor(n_estimators=300,random_state=42,n_jobs=-1)
        rf.fit(X, y)

        imp = pd.Series(rf.feature_importances_, index=X.columns)
        imp_sorted = imp.sort_values(ascending=False)

        keep = max(1, int(len(imp_sorted) * 0.7))
        top_feats = imp_sorted.index[:keep].tolist()
        return top_feats

    # MAIN MULTIVARIATE PIPELINE
    def run_multivariate(self, series):
        MAX_ROWS = 1000
        if len(series) > MAX_ROWS:
            series = series.tail(MAX_ROWS)

        df = pd.DataFrame({"y": series})
        df = self._add_features(df)
        last_t = df["t"].iloc[-1]

        # 80/20 split
        split = int(len(series) * 0.8)
        train = df.iloc[:split]
        test = df.iloc[split:]

        X_train = train.drop(columns=["y"])
        y_train = train["y"]

        X_test = test.drop(columns=["y"])
        y_test = test["y"]

        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        X_train_scaled = pd.DataFrame(
            scaler.fit_transform(X_train),
            index=X_train.index,
            columns=X_train.columns,
        )

        fs_window = min(365, len(X_train))
        top_feats = self._select_features(
            X_train_scaled.tail(fs_window),
            y_train.tail(fs_window),
        )
        X_train = X_train[top_feats]
        X_test = X_test[top_feats]

        # MODEL CANDIDATES — SAME MODELS USED IN forecasting_engine
        candidates = {
            "LightGBM": lgb.LGBMRegressor(n_estimators=300,learning_rate=0.05,objective="regression", verbose=-1,),
            "XGBoost": XGBRegressor(n_estimators=300,learning_rate=0.05,max_depth=6,subsample=0.8,colsample_bytree=0.8,
                                    objective="reg:squarederror",n_jobs=-1,verbosity=0,random_state=42,),
            "HistGB": HistGradientBoostingRegressor(max_depth=6),
            "RandomForest": RandomForestRegressor(n_estimators=300, n_jobs=-1),
            "ExtraTrees": ExtraTreesRegressor(n_estimators=300, n_jobs=-1),
        }

        results = {}

        # Evaluate each model
        for name, model in candidates.items():
            try:
                model.fit(X_train, y_train)
                y_pred_test = model.predict(X_test)
                score = wmape(y_test.values, y_pred_test)
                results[name] = {
                    "model": model,
                    "wmape": score,
                    "test_pred": pd.Series(y_pred_test, index=X_test.index),
                }
            except Exception:
                continue

        if not results:
            raise RuntimeError("All multivariate models failed.")

        # Select best model by WMAPE
        best_name = min(results.keys(), key=lambda k: results[k]["wmape"])
        best_info = results[best_name]
  
        best_model = best_info["model"]
        best_wmape = best_info["wmape"]
        best_test_pred = best_info["test_pred"]

        # Retrain best model on FULL DATA
        X_full = df.drop(columns=["y"])[top_feats]
        y_full = df["y"]

        best_model.fit(X_full, y_full)

        # Forecast next 60 days
        future_df = self._make_future_df(series.index.max(), 60, last_t, df["y"])
        
        for col in top_feats:
            if col not in future_df.columns:
                future_df[col] = 0

        future_df = future_df[top_feats]

        future_pred = best_model.predict(future_df)
        forecast_series = pd.Series(future_pred, index=future_df.index)

        recent = series.tail(14)
        if len(recent) >= 3:
            max_step = recent.diff().abs().quantile(0.95)
        else:
            max_step = recent.std() if recent.std() > 0 else recent.mean()

        guarded = [forecast_series.iloc[0]]

        for val in forecast_series.iloc[1:]:
            prev = guarded[-1]
            step = val - prev
            if abs(step) > max_step:
                step = np.sign(step) * max_step
            guarded.append(prev + step)

        forecast_series = pd.Series(
            guarded,
            index=forecast_series.index
        )
                
        if len(series) > 0 and len(forecast_series) > 0:
            anchor = series.tail(7).mean()
            offset = anchor - forecast_series.iloc[0]
            forecast_series = forecast_series + offset

        accuracy = round((1 - best_wmape) * 100, 2)

        name_map = {
            "LightGBM": "LightGBM",
            "XGBoost": "XGBoost",
            "HistGB": "HistGB",
            "RandomForest": "RandomForest",
            "ExtraTrees": "ExtraTrees",
        }
        best_name_normalized = name_map.get(best_name, best_name)

        return {
            "train": train["y"],
            "test": y_test,
            "test_pred": best_test_pred,
            "forecast": forecast_series,
            "best_model": best_name_normalized,
            "wmape": best_wmape,
            "accuracy": accuracy,
            "top_features": top_feats,
        }
