from typing import Union
import pandas as pd
import numpy as np

def forecast_accuracy(y_true: pd.Series, y_pred: pd.Series) -> float:

    y_true, y_pred = y_true.align(y_pred, join="inner")

    mask = ~y_true.isna()
    y_true = y_true[mask]
    y_pred = y_pred[mask]

    total_abs_error = (y_true - y_pred).abs().sum()
    total_abs_true = y_true.abs().sum()

    if total_abs_true == 0:
        return 0.0

    acc = 1.0 - (total_abs_error / total_abs_true)
    return round(acc * 100, 2)

def wmape(y_true, y_pred) -> float:

    y_true = pd.Series(y_true).astype(float)
    y_pred = pd.Series(y_pred).astype(float)

    y_true, y_pred = y_true.align(y_pred, join="inner")

    mask = ~y_true.isna()
    y_true = y_true[mask]
    y_pred = y_pred[mask]

    denom = y_true.abs().sum()
    denom = max(denom, 5.0)

    return float((y_true.sub(y_pred).abs().sum() / denom))


def trend_error(train_series: pd.Series, forecast_series: pd.Series) -> float:

    if forecast_series is None or forecast_series.empty:
        return 1.0

    recent = train_series.tail(min(21, len(train_series)))
    if len(recent) < 7:
        return 0.0

    x = np.arange(len(recent))
    y = recent.values.astype(float)

    try:
        actual_slope = np.polyfit(x, y, 1)[0]
    except Exception:
        actual_slope = 0.0

    fx = np.arange(len(forecast_series))
    fy = forecast_series.values.astype(float)

    try:
        forecast_slope = np.polyfit(fx, fy, 1)[0]
    except Exception:
        forecast_slope = 0.0

    denom = abs(actual_slope) + 1e-6
    return abs(actual_slope - forecast_slope) / denom


def variance_penalty(train_series: pd.Series, forecast_series: pd.Series) -> float:

    if forecast_series is None or forecast_series.empty:
        return 1.0

    train_std = float(train_series.tail(30).std())
    forecast_std = float(forecast_series.std())

    if train_std <= 1e-6:
        return 0.0

    ratio = forecast_std / train_std
    return abs(1.0 - ratio)

